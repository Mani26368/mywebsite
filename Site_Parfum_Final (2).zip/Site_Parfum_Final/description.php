<?php
require ('session_manager.php');
// Connexion à la base de données

try {
    $db = new PDO('mysql:host=localhost;dbname=gestion_projet;charset=utf8', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

// Vérifier si un ID de produit est fourni
// Connexion à la base de données
try {
    $db = new PDO('mysql:host=localhost;dbname=gestion_projet;charset=utf8', 'root', '');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

// Vérifier si un ID de produit est fourni
if (isset($_GET['id'])) { // Utilisation de 'id' au lieu de 'Id_Parfum'
    $id = intval($_GET['id']); // Sécuriser l'entrée
    $query = $db->prepare('SELECT * FROM Parfum WHERE Id_Parfum = ?');
    $query->execute([$id]);
    $produit = $query->fetch(PDO::FETCH_OBJ);

    if (!$produit) {
        echo "Produit introuvable.";
        exit;
    }
} else {
    echo "Aucun produit sélectionné.";
    exit;
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($produit->Nom_Parfum) ?></title>
    <style>
        /* CSS intégré */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color:#e3c6b3;
            color: #333;
        }
        .conteneur {
            max-width: 1000px;
            margin: 100px auto;
            height: auto;
            background: #f4e1d2;
            padding: 20px;
            border-radius: 30px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .image-et-taille {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .image-et-taille img {
            max-width: 100%;
            max-height: 400px;
            object-fit: contain;
            border-radius: 8px;
        }
        .produit {
            flex: 1;
        }
        .produit h2 {
            margin: 0 0 10px;
            font-size: 24px;
            color: #555;
        }
        .produit h3 {
            margin: 10px 0;
            color: #888;
        }
        .desc {
            margin: 20px 0;
            font-size: 16px;
            line-height: 1.6;
        }
        .addcart a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #5cb85c;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }
        .addcart a:hover {
            background-color: #4cae4c;
        }
        .addcart form {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
        }
        .addcart input[type="number"] {
            width: 60px;
            margin-right: 10px;
        }
        .addcart button {
            padding: 10px 20px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
        }
        .addcart button:hover {
            background-color: #4cae4c;
        }

        /* Media Queries */
        @media (max-width: 768px) {
            .conteneur {
                margin: 20px;
            }
            .image-et-taille {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }
            .produit h2 {
                font-size: 20px;
            }
            .produit h3 {
                font-size: 18px;
            }
            .desc {
                font-size: 14px;
            }
            .addcart input[type="number"] {
                width: 100%;
                margin-bottom: 10px;
            }
            .addcart button {
                width: 100%;
                padding: 12px;
            }
        }

        @media (max-width: 480px) {
            .conteneur {
                padding: 15px;
            }
            .produit h2 {
                font-size: 18px;
            }
            .produit h3 {
                font-size: 16px;
            }
            .desc {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class="conteneur">
        <div class="image-et-taille">
            <img src="<?= htmlspecialchars($produit->image) ?>" alt="<?= htmlspecialchars($produit->Nom_Parfum) ?>">
            <div class="produit">
                <h2><?= htmlspecialchars($produit->Nom_Parfum) ?></h2>
                <h3>Prix : <?= htmlspecialchars($produit->Prix_Parfum) ?> €</h3>
                <div class="desc">
                    <p><?= htmlspecialchars($produit->Description) ?></p>
                </div>
                <div class="addcart">
                    <form action="liste_panier.php" method="get">
                        <label for="quantite">Quantité :</label>
                        <input type="number" id="quantite" name="quantite" value="1" min="1" required>
                        <input type="hidden" name="id" value="<?= htmlspecialchars($produit->Id_Parfum) ?>">
                        <button type="submit">Ajouter au panier</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
