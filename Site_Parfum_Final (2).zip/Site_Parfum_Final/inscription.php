<?php
// Connexion
$serveur = "localhost";
$utilisateur = "root";
$motdepasse = "";
$base = "gestion_projet";

$conn = mysqli_connect($serveur, $utilisateur, $motdepasse, $base);

// Vérification de la connexion
if (!$conn) {
    die("La connexion a échoué : " . mysqli_connect_error());
}

// Récupération des données du formulaire
$nom = $_POST["Nom"];
$email = $_POST["Email"];
$password = $_POST["Password"];
$adresse = $_POST["Adresse"]; // Nouveau champ

// Vérifier si l'email est déjà pris
$sqlCheckEmail = "SELECT * FROM utilisateur WHERE Email = ?";
$stmtCheckEmail = mysqli_prepare($conn, $sqlCheckEmail);
mysqli_stmt_bind_param($stmtCheckEmail, "s", $email);
mysqli_stmt_execute($stmtCheckEmail);
$resultCheckEmail = mysqli_stmt_get_result($stmtCheckEmail);

// Si l'email existe déjà
if (mysqli_num_rows($resultCheckEmail) > 0) {
    echo "<h2>Ce compte existe déjà. Veuillez vous connecter.</h2>";
    echo "<p><a href='connexion.html'>Cliquez ici pour vous connecter</a></p>";
    exit();
}

// Hachage du mot de passe
$password_hache = password_hash($password, PASSWORD_BCRYPT);

// Création de la requête préparée pour l'insertion
$sql = "INSERT INTO utilisateur (Nom_utilisateur, Email, password, Adresse) VALUES (?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $sql);

if ($stmt) {
    // Liaison des paramètres avec la bonne chaîne de types
    mysqli_stmt_bind_param($stmt, "ssss", $nom, $email, $password_hache, $adresse);

    // Exécution de la requête
    if (mysqli_stmt_execute($stmt)) {
        echo "<h2>Inscription réussie !</h2>";
        echo "<p><a href='connexion.html'>Cliquez ici pour vous connecter.</a></p>";
    } else {
        echo "Erreur lors de l'insertion : " . mysqli_error($conn);
    }
} else {
    echo "Erreur dans la préparation de la requête : " . mysqli_error($conn);
}

// Fermeture de la connexion
mysqli_close($conn);
?>
