<?php
// Initialisation de la session
session_start();

// Vérification si une session est active
if (isset($_SESSION['email'])) {
    // Suppression de toutes les variables de session
    session_unset();

    // Destruction de la session
    session_destroy();

    // Redirection vers la page de connexion ou d'accueil
    header("Location: index.html"); // Remplacez "index.html" par la page que vous voulez afficher après la déconnexion
    exit();
} else {
    echo "<h2>Aucune session active à déconnecter.</h2>";
    exit();
}
?>
