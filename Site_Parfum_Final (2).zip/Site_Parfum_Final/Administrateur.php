<?php
require('session_manager.php');
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
  // Si l'utilisateur n'est pas connecté ou n'est pas un admin, le rediriger vers la page de connexion
  header("Location: connexion.html"); 
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Page Administrateur</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
  <style>
    /* Style global */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(145deg, #00b894, #00cec9);
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #2d3436;
    }

    /* Conteneur principal */
    .admin-container {
      background: #ffffff;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      padding: 40px 50px;
      width: 400px;
      text-align: center;
      animation: fadeIn 0.8s ease-out;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(-20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    /* Titre principal */
    .admin-container h1 {
      font-size: 28px;
      font-weight: 600;
      color: #0984e3;
      margin-bottom: 30px;
    }

    .button {
      display: block;
      width: 100%;
      padding: 12px 20px;
      margin: 10px 0;
      background: #0984e3;
      color: #fff;
      text-decoration: none;
      font-size: 18px;
      font-weight: bold;
      border-radius: 8px;
      transition: all 0.3s ease;
      text-align: center;
    }
    .button:hover {
      background: #6c5ce7;
      transform: translateY(-3px);
      box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
    }

    /* Bouton de déconnexion spécifique */
    .logout-button {
      width: auto; /* Ajuster la largeur du bouton */
      position: fixed; /* Fixer le bouton en bas à droite */
      bottom: 40px; /* Espacement du bas */
      right: 40px; /* Espacement de la droite */
      padding: 14px 28px;
      background-color: #e74c3c; /* Couleur différente pour le bouton */
      color: white;
      font-size: 18px;
      border-radius: 50px; /* Forme arrondie */
      text-align: center;
      transition: all 0.3s ease;
    }
    .logout-button:hover {
      background-color: #c0392b; /* Couleur plus foncée au survol */
      transform: translateY(-3px);
      box-shadow: 0 5px 15px rgba(192, 57, 43, 0.3);
    }

    /* Animation */
    .admin-container {
      animation: fadeIn 1s ease-in-out;
    }
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: scale(0.9);
      }
      to {
        opacity: 1;
        transform: scale(1);
      }
    }
    /* Footer (facultatif) */
    .footer {
      margin-top: 20px;
      font-size: 14px;
      color: #636e72;
    }

    .footer a {
      color: #0984e3;
      text-decoration: none;
      font-weight: 500;
    }

    .footer a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="admin-container">
    <h1>Page Administrateur</h1>
    <a href="ajouterparfum.php" class="button">Ajouter un Parfum</a>
    <a href="modifier_parfum.php" class="button">Modifier un Parfum</a>
    <a href="supprimer_parfum.php" class="button">Supprimer un Parfum</a>
    <a href="facture_admin.php" class="button">Voir les Factures</a>
    <div class="footer">
      <p>&copy; 2024 Votre Entreprise. <a href="#">Mentions légales</a></p>
    </div>
    <a href="deconnexion.php" class="logout-button">Déconnexion</a>
    <a href="index.html">Acceder a l'acceuil</a>
  </div>

  <script>
    // Exemple : Redirection console lors du clic (optionnel)
    document.querySelectorAll('.button').forEach(button => {
      button.addEventListener('click', () => {
        console.log(`Redirection vers ${button.textContent}`);
      });
    });
  </script>
</body>
</html>
