<?php
// Vérifier si un message de succès a été passé en paramètre
if (isset($_GET['message']) && $_GET['message'] == 'motdepasse_modifie') {
    $message = "Votre mot de passe a été modifié avec succès.";
} else {
    $message = "Erreur inconnue.";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Succès</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin: 50px auto;
            text-align: center;
        }
        h2 {
            color: #333;
        }
        p {
            color: #4CAF50;
            font-size: 18px;
            margin-bottom: 20px;
        }
        a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <center>
        <div class="container">
            <h2>Succès</h2>
            <p><?php echo $message; ?></p>
            <a href="index.html">Retour à l'accueil</a>
        </div>
    </center>
</body>
</html>
