<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gestion_projet"; // Remplacez par votre nom de base de données

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Récupérer les factures des utilisateurs ayant validé leurs commandes
$sql = "SELECT utilisateur.Id_utilisateur, utilisateur.Nom_utilisateur, utilisateur.Email, commande.Date_commande, commande.Montant_total 
        FROM utilisateur
        INNER JOIN commande ON utilisateur.Id_utilisateur = commande.Id_utilisateur
        WHERE commande.valide = 1"; 

$result = $conn->query($sql);

// Vérification si la requête a échoué ou si aucune ligne n'est retournée
if (!$result) {
    die("Erreur de la requête SQL : " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Factures des Commandes</title>
  <style>
    /* Style de base */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Arial', sans-serif;
      background: linear-gradient(135deg, #74b9ff, #00cec9);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    /* Conteneur principal */
    .facture-container {
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
      text-align: center;
      width: 700px;
      overflow-x: auto;
    }

    /* Titre principal */
    .facture-container h1 {
      margin-bottom: 20px;
      font-size: 26px;
      color: #2d3436;
      font-weight: bold;
    }

    /* Style des tables */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #0984e3;
      color: white;
    }

    /* Style des boutons */
    .button {
      display: inline-block;
      padding: 8px 15px;
      background: #0984e3;
      color: #fff;
      text-decoration: none;
      font-size: 16px;
      font-weight: bold;
      border-radius: 8px;
      transition: all 0.3s ease;
      margin-top: 10px;
    }
    .button:hover {
      background: #6c5ce7;
      transform: translateY(-3px);
      box-shadow: 0 5px 15px rgba(108, 92, 231, 0.3);
    }
  </style>
</head>
<body>
  <div class="facture-container">
    <h1>Liste des Factures</h1>
    <?php if ($result->num_rows > 0): ?>
    <table>
      <thead>
        <tr>
          <th>ID Utilisateur</th>
          <th>Nom</th>
          <th>Email</th>
          <th>Date de Commande</th>
          <th>Montant</th>
          <th>Voir Facture</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?php echo $row['Id_utilisateur']; ?></td>
          <td><?php echo $row['Nom_utilisateur']; ?></td>
          <td><?php echo $row['Email']; ?></td>
          <td><?php echo $row['Date_commande']; ?></td>
          <td><?php echo $row['Montant_total']; ?> djf</td>
          <td><a href="facture_detail.php?id=<?php echo $row['Id_utilisateur']; ?>" class="button">Voir</a></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php else: ?>
      <p>Aucune facture à afficher.</p>
    <?php endif; ?>
  </div>

  <?php
  // Fermer la connexion à la base de données
  $conn->close();
  ?>
</body>
</html>
