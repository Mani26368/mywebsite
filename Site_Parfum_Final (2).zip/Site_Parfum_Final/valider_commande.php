<?php
// Configuration de la session
session_start();

// Vérification si l'utilisateur est connecté
if (!isset($_SESSION['utilisateur'])) {
    echo "<p>Vous devez être connecté pour valider votre panier.</p>";
    exit;
}

// Connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";
$motdepasse = "";
$base = "gestion_projet";

$conn = mysqli_connect($serveur, $utilisateur, $motdepasse, $base);

if (!$conn) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

// Identifiant de l'utilisateur connecté (email de l'utilisateur)
$emailUtilisateur = $_SESSION['utilisateur'];

// Récupérer l'ID de l'utilisateur à partir de son email
$sqlUtilisateur = "SELECT Id_utilisateur FROM utilisateur WHERE Email = ?";
$stmtUtilisateur = mysqli_prepare($conn, $sqlUtilisateur);
mysqli_stmt_bind_param($stmtUtilisateur, "s", $emailUtilisateur);
mysqli_stmt_execute($stmtUtilisateur);
$resultUtilisateur = mysqli_stmt_get_result($stmtUtilisateur);

// Vérification que l'utilisateur existe et récupération de son Id_utilisateur
if ($rowUtilisateur = mysqli_fetch_assoc($resultUtilisateur)) {
    $idUtilisateur = $rowUtilisateur['Id_utilisateur'];
} else {
    echo "<p>Utilisateur non trouvé.</p>";
    exit;
}

// Requête pour récupérer les produits dans le panier de cet utilisateur
$sqlPanier = "
    SELECT p.Id_Parfum, p.Nom_Parfum, p.Prix_Parfum, pa.Quantite 
    FROM panier pa 
    JOIN parfum p ON pa.Id_Parfum = p.Id_Parfum 
    WHERE pa.Id_utilisateur = ?
";
$stmt = mysqli_prepare($conn, $sqlPanier);
mysqli_stmt_bind_param($stmt, "i", $idUtilisateur);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Vérification des résultats
$produits = [];
$total = 0;
while ($row = mysqli_fetch_assoc($result)) {
    $produits[] = $row;
    $total += $row['Prix_Parfum'] * $row['Quantite']; // Calcul du total
}

mysqli_stmt_close($stmt);
mysqli_close($conn);

// Affichage de la facture et de la date de livraison estimée
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validation de commande</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 70%;
            max-width: 800px;
            box-sizing: border-box;
        }

        h2 {
            text-align: center;
            font-size: 28px;
            color: #333;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .facture h3 {
            font-size: 24px;
            color: #555;
            margin-bottom: 10px;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        td {
            font-size: 16px;
            color: #333;
        }

        .total {
            font-size: 18px;
            font-weight: bold;
            background-color: #eaf2f8;
        }

        .livraison {
            background-color: #eaf2f8;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .livraison p {
            text-align: center;
            font-size: 18px;
            color: #333;
            font-weight: bold;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 12px 24px;
            border: none;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }

        .facture-table {
            width: 100%;
            margin: 20px 0;
        }

        .facture-table th, .facture-table td {
            text-align: center;
            padding: 10px;
            border: 1px solid #ccc;
        }

        .facture-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .facture-table td {
            font-size: 16px;
            color: #555;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Validation de votre commande</h2>

    <div class="facture">
        <h3>Détails de votre commande</h3>
        <table class="facture-table">
            <tr>
                <th>Produit</th>
                <th>Prix Unitaire</th>
                <th>Quantité</th>
                <th>Total</th>
            </tr>
            <?php foreach ($produits as $produit): ?>
                <tr>
                    <td><?= htmlspecialchars($produit['Nom_Parfum']) ?></td>
                    <td><?= htmlspecialchars(number_format($produit['Prix_Parfum'], 2)) ?> djf</td>
                    <td><?= htmlspecialchars($produit['Quantite']) ?></td>
                    <td><?= htmlspecialchars(number_format($produit['Prix_Parfum'] * $produit['Quantite'], 2)) ?> djf</td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td class="total" colspan="4">Total : <?= number_format($total, 2) ?> djf</td>
            </tr>
        </table>
    </div>

    <div class="livraison">
        <p><strong>Date estimée de livraison :</strong> <?= date("d/m/Y", strtotime("+5 days")) ?></p>
    </div>

    <!-- Ajout du bouton de confirmation -->
    <form action="confirmation_commande.php" method="POST">
        <button type="submit" name="confirmation_commande">Confirmer la commande</button>
    </form>

</div>

</body>
</html>
