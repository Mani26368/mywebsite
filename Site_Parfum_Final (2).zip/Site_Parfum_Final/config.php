<?php
// Informations de connexion à la base de données MySQL
$host = "sql101.infinityfree.com";  // Hôte de la base de données MySQL
$user = "if0_38338130";            // Nom d'utilisateur de la base de données MySQL
$pass = "makomed1";                // Mot de passe de la base de données MySQL
$db   = "if0_38338130_XXX";        // Nom de la base de données MySQL (remplace XXX par ton vrai nom de base)

// Connexion à la base de données
$conn = mysqli_connect($host, $user, $pass, $db);

// Vérifier la connexion
if (!$conn) {
    die("Échec de la connexion : " . mysqli_connect_error());
}

echo "Connexion réussie à la base de données !";
?>
