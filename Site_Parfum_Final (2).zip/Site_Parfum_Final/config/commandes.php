<?php



function afficher()
{
	if(require("connexion.php"))
	{
		$req=$access->prepare("SELECT * FROM parfum ORDER BY id_Parfum DESC");

        $req->execute();

        $data = $req->fetchAll(PDO::FETCH_OBJ);

        $req->closeCursor();
        return $data;
	}
}

