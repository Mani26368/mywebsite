<?php
// Configuration de la session
session_start();

// Connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";
$motdepasse = "";
$base = "gestion_projet";

$conn = mysqli_connect($serveur, $utilisateur, $motdepasse, $base);

if (!$conn) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

// Vérification si un utilisateur ou un admin est connecté
if (!isset($_SESSION['email'])) {
    echo "<p>Vous n'êtes pas connecté. <a href='connexion.html'>Connectez-vous</a> pour voir votre panier.</p>";
    exit;
}

$emailUtilisateur = $_SESSION['email'];
$roleUtilisateur = $_SESSION['role'];

// Récupérer les informations de l'utilisateur connecté
if ($roleUtilisateur === 'utilisateur') {
    $sqlUtilisateur = "SELECT Id_utilisateur, Nom_utilisateur, Email, Adresse FROM utilisateur WHERE Email = ?";
} elseif ($roleUtilisateur === 'admin') {
    $sqlUtilisateur = "SELECT Email AS Nom_utilisateur, Email, '' AS Adresse FROM boutique WHERE Email = ?";
} else {
    echo "<p>Session invalide. <a href='connexion.php'>Reconnectez-vous</a>.</p>";
    exit;
}

$stmtUtilisateur = mysqli_prepare($conn, $sqlUtilisateur);
mysqli_stmt_bind_param($stmtUtilisateur, "s", $emailUtilisateur);
mysqli_stmt_execute($stmtUtilisateur);
$resultUtilisateur = mysqli_stmt_get_result($stmtUtilisateur);

if ($rowUtilisateur = mysqli_fetch_assoc($resultUtilisateur)) {
    $idUtilisateur = $roleUtilisateur === 'utilisateur' ? $rowUtilisateur['Id_utilisateur'] : null;
    $nomUtilisateur = $rowUtilisateur['Nom_utilisateur'];
    $emailUtilisateur = $rowUtilisateur['Email'];
    $adresseUtilisateur = $rowUtilisateur['Adresse'];
} else {
    echo "<p>Utilisateur non trouvé. <a href='connexion.php'>Reconnectez-vous</a>.</p>";
    exit;
}

// Récupérer les produits du panier pour les utilisateurs uniquement
$produits = [];
if ($roleUtilisateur === 'utilisateur') {
    $sqlPanier = "
        SELECT p.Id_Parfum, p.Nom_Parfum, p.Prix_Parfum, p.Image, p.Description, pa.Quantite 
        FROM panier pa 
        JOIN parfum p ON pa.Id_Parfum = p.Id_Parfum 
        WHERE pa.Id_utilisateur = ? AND pa.commande_validee = 0
    ";
    $stmt = mysqli_prepare($conn, $sqlPanier);
    mysqli_stmt_bind_param($stmt, "i", $idUtilisateur);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($row = mysqli_fetch_assoc($result)) {
        $produits[] = $row;
    }

    mysqli_stmt_close($stmt);
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panier</title>
    <link rel="stylesheet" href="panier.css">
</head>
<body>

<!-- Menu latéral -->
<section class="sidebar">
    <img src="image/pers.png" alt="Profil">
    <h2>Bienvenue, <?= htmlspecialchars($nomUtilisateur) ?></h2>
    <p>Email: <?= htmlspecialchars($emailUtilisateur) ?></p>
    <?php if ($roleUtilisateur === 'utilisateur'): ?>
        <p>Adresse: <?= htmlspecialchars($adresseUtilisateur) ?></p>
    <?php endif; ?>
    <a href="index.html" class="active">Home</a>
    <?php if ($roleUtilisateur === 'utilisateur'): ?>
        <a href="Homme.php">Parfums Homme</a>
        <a href="Femme.php">Parfums Femme</a>
        <a href="Mixte.php">Parfums Mixte</a>
    <?php endif; ?>
    <a href="deconnexion.php" class="logout">Déconnexion</a>
</section>

<!-- Conteneur principal -->
<section class="container">
    <?php if ($roleUtilisateur === 'utilisateur' && !empty($produits)): ?>
        <section class="produits">
            <?php foreach ($produits as $produit): ?>
                <article class="card">
                    <img src="<?= htmlspecialchars($produit['Image']) ?>" alt="<?= htmlspecialchars($produit['Nom_Parfum']) ?>">
                    <h3><?= htmlspecialchars($produit['Nom_Parfum']) ?></h3>
                    <p><strong><?= htmlspecialchars(number_format($produit['Prix_Parfum'], 2)) ?> djf</strong></p>
                    <p>Quantité: <?= htmlspecialchars($produit['Quantite']) ?></p>
                    <form action="supprimer_panier.php" method="post">
                        <input type="hidden" name="Id_Parfum" value="<?= htmlspecialchars($produit['Id_Parfum']) ?>">
                        <button type="submit">Supprimer</button>
                    </form>
                    <form action="valider_commande.php" method="get">
                        <input type="hidden" name="idProduit" value="<?= htmlspecialchars($produit['Id_Parfum']) ?>">
                        <button type="submit">Valider</button>
                    </form>
                </article>
            <?php endforeach; ?>
        </section>
    <?php elseif ($roleUtilisateur === 'utilisateur'): ?>
        <section class="panier-vide">
            <p>Votre panier est vide.</p>
            <p><a href='tous.php'>Cliquez pour faire des achats.</a></p>
        </section>
    <?php else: ?>
        <section class="admin-gestion">
            <p>Veuillez gérer les produits et les commandes.</p>
            <p><a href='Administrateur.php'>Cliquez ici</a>.</p>
        </section>
    <?php endif; ?>
</section>

</body>
</html>
