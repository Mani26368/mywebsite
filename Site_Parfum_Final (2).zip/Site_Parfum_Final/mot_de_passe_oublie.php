<?php
// Connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";
$motdepasse = "";
$base = "gestion_projet";

$conn = mysqli_connect($serveur, $utilisateur, $motdepasse, $base);

if (!$conn) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

// Si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $nouveau_motdepasse = mysqli_real_escape_string($conn, $_POST["nouveau_motdepasse"]);
    $confirmation_motdepasse = mysqli_real_escape_string($conn, $_POST["confirmation_motdepasse"]);

    // Vérifier si l'email existe et récupérer les informations de l'utilisateur
    $sql = "SELECT * FROM utilisateur WHERE Email = ?";
    $stmt = mysqli_prepare($conn, $sql);
    
    // Vérifier si la préparation de la requête a réussi
    if ($stmt === false) {
        die("Erreur lors de la préparation de la requête : " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        // Vérifier que le nouveau mot de passe et la confirmation correspondent
        if ($nouveau_motdepasse == $confirmation_motdepasse) {
            // Hacher le nouveau mot de passe
            $motdepasse_hash = password_hash($nouveau_motdepasse, PASSWORD_DEFAULT);

            // Mettre à jour le mot de passe dans la base de données
            $sqlUpdate = "UPDATE utilisateur SET Password = ? WHERE Email = ?";
            $stmtUpdate = mysqli_prepare($conn, $sqlUpdate);

            // Vérifier si la préparation de la requête a réussi
            if ($stmtUpdate === false) {
                die("Erreur lors de la préparation de la requête de mise à jour : " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param($stmtUpdate, "ss", $motdepasse_hash, $email);
            if (mysqli_stmt_execute($stmtUpdate)) {
                // Rediriger vers une page de succès après la mise à jour
                header("Location: success.php?message=motdepasse_modifie");
                exit();
            } else {
                echo "Erreur lors de la mise à jour du mot de passe.";
            }
        } else {
            echo "Les mots de passe ne correspondent pas.";
        }
    } else {
        echo "Aucun utilisateur trouvé avec cet email.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier le Mot de Passe</title>
    <style>
        /* Style global */
        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: #fff;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }

        h2 {
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
            font-weight: 600;
        }

        input[type="email"],
        input[type="password"],
        button {
            width: 100%;
            padding: 15px;
            margin: 10px 0;
            border-radius: 10px;
            border: 1px solid #ccc;
            font-size: 16px;
            outline: none;
            transition: all 0.3s ease;
        }

        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: #2575fc;
            box-shadow: 0 0 5px rgba(37, 117, 252, 0.8);
        }

        button {
            background-color: #2575fc;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        button:hover {
            background-color: #1e64d3;
            transform: scale(1.05);
        }

        .error-message {
            color: #ff4d4d;
            margin-top: 10px;
            font-size: 14px;
        }

        .success-message {
            color: #4caf50;
            margin-top: 10px;
            font-size: 16px;
        }

        a {
            color: #2575fc;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Animation d'entrée des champs */
        input[type="email"],
        input[type="password"] {
            opacity: 0;
            transform: translateY(10px);
            animation: fadeInUp 0.5s forwards;
        }

        button {
            opacity: 0;
            transform: translateY(10px);
            animation: fadeInUp 0.7s forwards;
            animation-delay: 0.3s;
        }

        /* Animation des messages d'erreur */
        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .error-message {
            opacity: 0;
            animation: fadeInError 0.5s forwards;
        }

        @keyframes fadeInError {
            to {
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Modifier votre Mot de Passe</h2>
        <form method="POST" action="" id="passwordForm">
            <input type="email" name="email" id="email" placeholder="Entrez votre email" required />
            <input type="password" name="nouveau_motdepasse" id="nouveau_motdepasse" placeholder="Nouveau mot de passe" required />
            <input type="password" name="confirmation_motdepasse" id="confirmation_motdepasse" placeholder="Confirmer le nouveau mot de passe" required />
            <button type="submit">Modifier le mot de passe</button>
        </form>

        <!-- Affichage des messages d'erreur ou de succès -->
        <p id="message" class="error-message"></p>

        <!-- Lien vers la page d'accueil -->
        <p><a href="tous.php">Retour à l'accueil</a></p>
    </div>

    <script>
        // Fonction de validation du formulaire avec animations d'erreur
        document.getElementById('passwordForm').addEventListener('submit', function(event) {
            let message = document.getElementById('message');
            let motdepasse = document.getElementById('nouveau_motdepasse').value;
            let confirmation = document.getElementById('confirmation_motdepasse').value;

            // Effacer les messages précédents
            message.textContent = "";

            // Vérifier si les mots de passe correspondent
            if (motdepasse !== confirmation) {
                event.preventDefault(); // Empêcher l'envoi du formulaire
                message.textContent = "Les mots de passe ne correspondent pas.";
                message.style.color = "#ff4d4d"; // Rouge pour l'erreur
                message.style.opacity = 1;
                return false;
            }

            // Vérification de la longueur du mot de passe
            if (motdepasse.length < 6) {
                event.preventDefault();
                message.textContent = "Le mot de passe doit comporter au moins 6 caractères.";
                message.style.color = "#ff4d4d";
                message.style.opacity = 1;
                return false;
            }

            // Si tout est correct
            message.textContent = "";
        });
    </script>
</body>
</html>
