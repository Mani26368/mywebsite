<?php

require ('session_manager.php');
require("config/commandes.php");

  $produits=afficher();

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>chanel_homme</title>
<link rel="stylesheet" href="style.css">
</head>
<style>
/* Conteneur du formulaire de recherche */
form {
    display: flex;
    justify-content: center;
    align-items: center;
    width: auto; /* Ajuste la largeur en fonction du contenu */
    margin: 10px 0;
}

/* Style pour le champ de saisie */
form input[type="text"] {
    padding: 8px 15px; /* Moins d'espace pour le champ de saisie */
    font-size: 12px; /* Taille de police réduite */
    border: 2px solid #ddd;
    border-radius: 20px 0 0 20px; /* Coins arrondis à gauche */
    width: 200px; /* Réduit la largeur de l'input */
    outline: none;
    transition: border-color 0.3s ease;
}

form input[type="text"]:focus {
    border-color: #f8bf21; /* Bordure dorée au focus */
}

form input[type="text"]::placeholder {
    color: #aaa;
}

/* Style pour le bouton de recherche */
form button {
    padding: 8px 15px; /* Moins d'espace pour le bouton */
    font-size: 12px; /* Taille de police réduite */
    background-color: #f8bf21; /* Couleur dorée */
    color: white;
    border: 2px solid #f8bf21;
    border-radius: 0 20px 20px 0; /* Coins arrondis à droite */
    cursor: pointer;
    transition: background-color 0.3s ease, border-color 0.3s ease;
}

form button:hover {
    background-color: #e1a800; /* Légèrement plus foncé au survol */
    border-color: #e1a800;
}



</style>
<body>
  
<nav>
        <div class="logo">
            <img src="images/logo.jpeg" alt="logo">
        </div>
        <button class="hamburger" aria-label="Toggle navigation">
            &#9776; <!-- Symbole de menu hamburger -->
        </button>
        <ul class="nav-links">
            <li><a href="index.html">Home</a></li>
            <li><a href="aboutus.html">About us</a></li>
            <li><a href="Homme.php">Homme</a></li>
            <li><a href="Femme.php">Femme</a></li>
            <li><a href="Mixte.php">Mixte</a></li>
            <li><a href="tous.php">All</a></li>
        </ul>
        <div class="search-bar">
        
            <div class="icon">
            <form action="search.php" method="GET">
                <input type="text" name="q" placeholder="Rechercher un produit..." required>
                <button type="submit">Rechercher</button>
            </form>
                <a href="connexion.html">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
                        <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6m2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0m4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4m-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10s-3.516.68-4.168 1.332c-.678.678-.83 1.418-.832 1.664z"/>
                    </svg>
                </a>
                <a href="panier.php">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-cart3" viewBox="0 0 16 16">
                        <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l.84 4.479 9.144-.459L13.89 4zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2"/>
                    </svg>
                </a>
            </div>
        </div>
    </nav>
<section class="tout">
<div id="message" style="display: none; color: red;">Veuillez vous connecter pour ajouter un produit au panier.</div>
<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "root", "", "gestion_projet");

// Vérification de la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer les parfums pour cette catégorie
$categorie = "homme"; 
$sql = "SELECT * FROM parfum WHERE Id_catalogue = 1 AND Id_Marque=1"; // Adaptez la requête selon votre besoin
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        ?>
        <div class="produits">
            <!--card debut-->
            <div class="card">
                <div class="title">
                    <h3><?= htmlspecialchars($row['Nom_Parfum']) ?></h3>
                </div>
                <div class="img">
                    <a href="description.php?id=<?= urlencode($row['Id_Parfum']) ?>">
                        <img src="<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['Nom_Parfum']) ?>">
                    </a>
                </div>
                <div class="box">
                    <div class="prix">
                        <small class="text-bold product-price"><?= htmlspecialchars($row['Prix_Parfum']) ?> €</small>
                    </div>
                    <div class="panier">
                       
                    </div>
                </div>
            </div>
            <!--card fin-->
        </div>
        <?php
    }
} else {
    echo "Aucun parfum trouvé.";
}

$conn->close();
?>
</section>


<footer>
    <div class="footer-container">
       
        <!-- Droits d'auteur -->
        <div class="footer-bottom">
            <p>&copy; 2024 Maison des Parfums. Tous droits réservés.</p>
        </div>
    </div>
</footer>
<script src="main.js"></script>
</body>

</html>