<?php
// Connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";
$motdepasse = "";
$base = "gestion_projet";

$conn = mysqli_connect($serveur, $utilisateur, $motdepasse, $base);
if (!$conn) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

// Vérifier que l'ID de l'utilisateur est passé dans l'URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Identifiant d'utilisateur invalide.");
}
$idUtilisateur = intval($_GET['id']); // Récupérer l'ID utilisateur à partir de l'URL

// Récupérer les commandes de cet utilisateur avec les informations sur le parfum et l'utilisateur
$sqlCommandes = "
    SELECT c.Id_commande, c.Montant_total, c.Date_commande, c.Date_livraison_estimee, 
           p.Nom_Parfum, p.Image, p.Prix_Parfum, c.Id_parfum, c.Quantite,
           u.Nom_utilisateur AS Nom_utilisateur, u.Email AS Email_utilisateur, u.Adresse AS Adresse_utilisateur
    FROM commande c
    JOIN parfum p ON c.Id_parfum = p.Id_Parfum
    JOIN utilisateur u ON c.Id_utilisateur = u.Id_utilisateur
    WHERE c.Id_utilisateur = ?";
$stmtCommandes = mysqli_prepare($conn, $sqlCommandes);

if (!$stmtCommandes) {
    die("Erreur dans la préparation de la requête SQL : " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmtCommandes, "i", $idUtilisateur);
mysqli_stmt_execute($stmtCommandes);
$resultCommandes = mysqli_stmt_get_result($stmtCommandes);

if (mysqli_num_rows($resultCommandes) > 0) {
    $userInfo = null;
    $products = [];
    $totalGeneral = 0;

    while ($rowCommande = mysqli_fetch_assoc($resultCommandes)) {
        // Stocker les informations générales de l'utilisateur et de la commande
        if (!$userInfo) {
            $userInfo = [
                'nomUtilisateur' => $rowCommande['Nom_utilisateur'],
                'emailUtilisateur' => $rowCommande['Email_utilisateur'],
                'adresseUtilisateur' => $rowCommande['Adresse_utilisateur'],
                'dateCommande' => $rowCommande['Date_commande'],
                'dateLivraison' => $rowCommande['Date_livraison_estimee'],
            ];
        }

        // Calculer le total pour chaque produit
        $totalProduit = $rowCommande['Prix_Parfum'] * $rowCommande['Quantite'];
        $totalGeneral += $totalProduit;

        // Ajouter les produits à un tableau
        $products[] = [
            'nomParfum' => $rowCommande['Nom_Parfum'],
            'imageParfum' => $rowCommande['Image'],
            'prixParfum' => $rowCommande['Prix_Parfum'],
            'quantite' => $rowCommande['Quantite'],
            'totalProduit' => $totalProduit,
        ];
    }

    // Afficher la facture
    ?>

    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Facture</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
                background: #f8f9fa;
            }
            .container {
                width: 90%;
                max-width: 800px;
                margin: 30px auto;
                padding: 20px;
                background: white;
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }
            h1, h2 {
                color: #2d3436;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
            }
            th, td {
                padding: 10px;
                border: 1px solid #ddd;
                text-align: left;
            }
            th {
                background: #0984e3;
                color: white;
            }
            img {
                max-width: 100px;
                height: auto;
                border-radius: 8px;
            }
            .total {
                text-align: right;
                font-size: 18px;
                font-weight: bold;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Facture</h1>

            <!-- Informations de l'utilisateur -->
            <h2>Informations de l'utilisateur</h2>
            <p><strong>Nom :</strong> <?php echo htmlspecialchars($userInfo['nomUtilisateur']); ?></p>
            <p><strong>Email :</strong> <?php echo htmlspecialchars($userInfo['emailUtilisateur']); ?></p>
            <p><strong>Adresse :</strong> <?php echo htmlspecialchars($userInfo['adresseUtilisateur']); ?></p>

            <!-- Informations générales de la commande -->
            <h2>Informations de la commande</h2>
            <p><strong>Date de commande :</strong> <?php echo htmlspecialchars($userInfo['dateCommande']); ?></p>
            <p><strong>Date de livraison estimée :</strong> <?php echo htmlspecialchars($userInfo['dateLivraison']); ?></p>

            <!-- Détails des produits -->
            <h2>Produits dans la commande</h2>
            <table>
                <thead>
                    <tr>
                        <th>Nom du Produit</th>
                        <th>Image</th>
                        <th>Quantité</th>
                        <th>Prix Unitaire (FDJ)</th>
                        <th>Total (FDJ)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($product['nomParfum']); ?></td>
                            <td><img src="<?php echo htmlspecialchars($product['imageParfum']); ?>" alt="Image produit"></td>
                            <td><?php echo $product['quantite']; ?></td>
                            <td><?php echo number_format($product['prixParfum'], 2, ',', ' '); ?></td>
                            <td><?php echo number_format($product['totalProduit'], 2, ',', ' '); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Montant total de la commande -->
            <p class="total"><strong>Montant Total :</strong> <?php echo number_format($totalGeneral, 2, ',', ' '); ?> €</p>
            <a href="Administrateur.php">
                            <input type="button" value="Administrateur" style="background-color: #e74c3c; color: white; border: none; padding: 15px 25px; border-radius: 8px; cursor: pointer; transition: background-color 0.3s ease; font-size: 18px;">
                        </a>
        </div>
    </body>
    </html>

    <?php
} else {
    echo "<p>Aucune commande trouvée pour cet utilisateur.</p>";
}

// Fermer la connexion à la base de données
mysqli_close($conn);
?>
