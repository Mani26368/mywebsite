<?php
// Configuration de la session
session_start();

// Connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";
$motdepasse = "";
$base = "gestion_projet";

try {
    $pdo = new PDO("mysql:host=$serveur;dbname=$base;charset=utf8", $utilisateur, $motdepasse);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Requête pour suggestions AJAX
if (isset($_GET['q']) && isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    $query = htmlspecialchars($_GET['q']);
    $stmt = $pdo->prepare("SELECT ID, Nom_Parfum, Prix_Parfum, image FROM parfum WHERE Nom_Parfum LIKE ?");
    $stmt->execute(["%$query%"]);
    $suggestions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($suggestions);
    exit;
}

// Requête pour afficher les résultats complets
if (isset($_GET['q']) && !isset($_GET['ajax'])) {
    $query = htmlspecialchars($_GET['q']);
    $stmt = $pdo->prepare("SELECT * FROM parfum WHERE Nom_Parfum LIKE ?");
    $stmt->execute(["%$query%"]);
    $produits = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche de Produits</title>
    <link rel="stylesheet" href="search.css">

</head>
<body>
    <nav>
        <h1>Recherche Produit</h1>
        <form action="search.php" method="GET">
            <input type="text" name="q" placeholder="Rechercher un produit..." required>
            <button type="submit">Rechercher</button>
        </form>
    </nav>

   <!-- Résultats complets -->
   <?php if (isset($produits) && !empty($produits)): ?>
        <div class="results">
            <h2>Résultats de recherche pour "<?= htmlspecialchars($query) ?>" :</h2>
            <div style="display: flex; flex-wrap: wrap; gap: 20px;">
                <?php foreach ($produits as $produit): ?>
                    <div class="product">
                        <a href="description.php?id=<?= htmlspecialchars($produit['Id_Parfum']) ?>">
                            <img src="<?= htmlspecialchars($produit['image']) ?>" alt="<?= htmlspecialchars($produit['Nom_Parfum']) ?>">
                        </a>
                        <div>
                            <h3><?= htmlspecialchars($produit['Nom_Parfum']) ?></h3>
                            <p>Prix : <?= htmlspecialchars($produit['Prix_Parfum']) ?> €</p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php elseif (isset($query)): ?>
        <div class="results">
            <p>Aucun produit trouvé pour "<?= htmlspecialchars($query) ?>"</p>
        </div>
    <?php endif; ?>
</body>
</html>