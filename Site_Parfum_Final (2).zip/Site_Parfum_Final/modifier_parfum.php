<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "root", "", "gestion_projet");

// Vérification de la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Variables pour les informations du parfum
$nom_parfum = $description = $prix = $image = "";
$id_parfum = 0;
$message = "";

// Vérification si un parfum est sélectionné pour modification
if (isset($_POST['parfum'])) {
    $id_parfum = $_POST['parfum'];

    // Requête pour récupérer les informations du parfum sélectionné
    $sql = "SELECT * FROM parfum WHERE Id_Parfum = $id_parfum";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nom_parfum = $row['Nom_Parfum'];
        $description = $row['Description'];
        $prix = $row['Prix_Parfum'];
        $image = $row['image'];
    } else {
        $message = "Parfum non trouvé.";
    }
}

// Vérification de la soumission du formulaire pour modifier le parfum
if (isset($_POST['modifier'])) {
    $nouveau_nom = $_POST['nomduproduit'];
    $nouvelle_description = $_POST['description'];
    $nouveau_prix = $_POST['prix'];
    $nouvelle_image = $_FILES['image']['name'];

    // Vérifier si une nouvelle image est téléchargée
    if ($nouvelle_image != "") {
        // Déplacer la nouvelle image dans le dossier 'images'
        $target_dir = "images/";
        $target_file = $target_dir . basename($nouvelle_image);
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
    } else {
        // Conserver l'ancienne image si aucune nouvelle image n'est téléchargée
        $target_file = $image;
    }

    // Requête pour mettre à jour le parfum
    $update_sql = "UPDATE parfum SET Nom_Parfum = '$nouveau_nom', Description = '$nouvelle_description', Prix_Parfum = '$nouveau_prix', image = '$target_file' WHERE Id_Parfum = $id_parfum";

    if ($conn->query($update_sql) === TRUE) {
        $message = "Parfum modifié avec succès.";
    } else {
        $message = "Erreur lors de la modification : " . $conn->error;
    }
}

// Récupérer tous les parfums pour le menu déroulant
$sql = "SELECT Id_Parfum, Nom_Parfum FROM parfum";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Parfum</title>
    <style>
        /* Global Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #74b9ff, #00cec9);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
        }

        /* Conteneur principal du formulaire */
        .form-container {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 80%;
            max-width: 800px;
            transition: transform 0.3s ease-in-out;
        }

        .form-container:hover {
            transform: scale(1.02);
        }

        h2 {
            text-align: center;
            color: #2d3436;
            font-size: 32px;
            margin-bottom: 30px;
        }

        /* Styles du formulaire */
        table {
            width: 100%;
            margin-bottom: 20px;
        }

        td {
            padding: 15px;
            vertical-align: middle;
        }

        label {
            font-size: 18px;
            color: #2d3436;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        textarea,
        select,
        input[type="file"] {
            width: 100%;
            padding: 12px;
            margin-top: 5px;
            font-size: 16px;
            border: 2px solid #ddd;
            border-radius: 8px;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="number"]:focus,
        textarea:focus,
        select:focus,
        input[type="file"]:focus {
            border-color: #0984e3;
        }

        textarea {
            resize: vertical;
            height: 150px;
        }

        /* Styles des boutons */
        input[type="submit"],
        input[type="reset"],
        input[type="button"] {
            background-color: #0984e3;
            color: white;
            font-size: 18px;
            border: none;
            padding: 15px 25px;
            border-radius: 8px;
            cursor: pointer;
           
        }

        input[type="submit"]:hover,
        input[type="reset"]:hover,
        input[type="button"]:hover {
            background-color: #6c5ce7;
            transform: translateY(-3px);
        }

        input[type="submit"]:active,
        input[type="reset"]:active,
        input[type="button"]:active {
            transform: translateY(0);
            background-color: #4e43d2;
        }

        /* Styles pour l'option vide du sélecteur */
        option {
            color: #7f8c8d;
        }

        /* Responsivité */
        @media (max-width: 768px) {
            .form-container {
                padding: 20px;
                width: 90%;
            }

            h2 {
                font-size: 28px;
            }

            button {
                font-size: 16px;
            }
        }

        /* Message de confirmation */
        .message {
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
            border-radius: 8px;
            padding: 15px;
            margin-top: 40px;
        }

        .message.success {
            background-color: #28a745;
            color: white;
        }

        .message.error {
            background-color: #dc3545;
            color: white;
        }

        /* Section pour afficher le nom et l'image du parfum */
        .parfum-info {
            margin-top: 20px;
            text-align: center;
        }

        .parfum-info img {
            max-width: 150px;
            max-height: 150px;
            margin-top: 10px;
            border-radius: 8px;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Modifier Parfum</h2>

    <?php if (!empty($message)) : ?>
        <div class="message <?= strpos($message, 'succès') !== false ? 'success' : 'error'; ?>"><?= $message; ?></div>
    <?php endif; ?>

    <?php if ($id_parfum == 0) : ?>
        <!-- Formulaire pour sélectionner un parfum à modifier -->
        <form action="modifier_parfum.php" method="POST">
            <label for="parfum">Sélectionner un parfum :</label>
            <select name="parfum" id="parfum" required>
                <option value="">Choisissez un parfum</option>
                <?php if ($result->num_rows > 0) : ?>
                    <?php while ($row = $result->fetch_assoc()) : ?>
                        <option value="<?= $row['Id_Parfum']; ?>"><?= $row['Nom_Parfum']; ?></option>
                    <?php endwhile; ?>
                <?php else : ?>
                    <option>Aucun parfum disponible</option>
                <?php endif; ?>
            </select>
            <input type="submit" value="Modifier">
        </form>
    <?php else : ?>
        <!-- Formulaire pour modifier un parfum -->
        <form action="modifier_parfum.php" method="POST" enctype="multipart/form-data">
            <table>
                <tr>
                    <td><label for="nomduproduit">Nom du parfum:</label></td>
                    <td><input type="text" name="nomduproduit" id="nomduproduit" value="<?= $nom_parfum; ?>" required /></td>
                </tr>
                <tr>
                    <td><label for="description">Description:</label></td>
                    <td><textarea name="description" id="description" required><?= $description; ?></textarea></td>
                </tr>
                <tr>
                    <td><label for="prix">Prix:</label></td>
                    <td><input type="number" name="prix" id="prix" value="<?= $prix; ?>" required /></td>
                </tr>
                <tr>
                    <td><label for="image">Image :</label></td>
                    <td><input type="file" name="image" id="image" /></td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="hidden" name="parfum" value="<?= $id_parfum; ?>" />
                        <input type="submit" name="modifier" value="Modifier">
                        <!-- Nouveau bouton pour aller à la page Administrateur -->
                        <a href="Administrateur.php">
                            <input type="button" value="Administrateur" style="background-color: #e74c3c; color: white; border: none; padding: 15px 25px; border-radius: 8px; cursor: pointer; transition: background-color 0.3s ease; font-size: 18px;">
                        </a>
                    </td>
                </tr>
            </table>
        </form>
        
    <?php endif; ?>
</div>

</body>
</html>
