<?php
// Récupérer le montant passé en GET
if (isset($_GET['total']) && is_numeric($_GET['total'])) {
    $total = $_GET['total'];
} else {
    die("Montant invalide.");
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Effectuer un paiement via PayPal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
        }
        h1 {
            color: #333;
        }
        .paypal-button {
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <h1>Effectuer un paiement via PayPal</h1>
    <p>Montant à payer : <?php echo number_format($total, 2, ',', ' '); ?> FDJ</p>
    
    <!-- Conteneur du bouton PayPal -->
    <div id="paypal-button-container" class="paypal-button"></div>

    <!-- Script PayPal SDK -->
    <script src="https://www.paypal.com/sdk/js?client-id=AaHNh9VpDT2iu3kqOTuRJVKy0aH-NIea2k6j2zpM5-0mazECNAOFOPAA_csWo1DBWbFXBq1IcJN0SzAi&currency=EUR"></script>

    <script>
        // Initialisation du bouton PayPal
        paypal.Buttons({
            // Créer la commande
            createOrder: function(data, actions) {
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: '<?php echo $total; ?>'  // Utiliser le montant récupéré en PHP
                        }
                    }]
                });
            },
            // Approuver et capturer le paiement
            onApprove: function(data, actions) {
                return actions.order.capture().then(function(details) {
                    alert('Paiement effectué avec succès ! \n' + details.payer.name.given_name);
                    
                    // Optionnel : Envoi des données de paiement à ton serveur pour traiter la commande
                    // Exemple : fetch('process_payment.php', { method: 'POST', body: JSON.stringify({ paymentStatus: 'success', orderId: details.id }) });
                });
            },
            // Gérer les erreurs éventuelles
            onError: function(err) {
                alert('Une erreur est survenue lors du paiement : ' + err);
            }
        }).render('#paypal-button-container');  // Rendu du bouton PayPal dans le conteneur spécifié
    </script>

</body>
</html>
