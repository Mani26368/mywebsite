const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

hamburger.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});


document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function (event) {
        event.preventDefault();
        const url = this.getAttribute('href');

        fetch(url)
            .then(response => response.json())
            .then(data => {
                const messageBox = document.getElementById('message');
                if (data.success) {
                    messageBox.style.color = 'green';
                } else {
                    messageBox.style.color = 'red';
                }
                messageBox.textContent = data.message;
                messageBox.style.display = 'block';

                setTimeout(() => {
                    messageBox.style.display = 'none';
                }, 3000); // Cacher le message après 3 secondes
            });
    });
});


