
<?php

    //Connexion
    $serveur = "localhost";
    $utilisateur = "root";
    $motdepasse = "";
    $base = "gestion_projet";

    $conn = mysqli_connect("$serveur","$utilisateur","$motdepasse","$base");

    
    $Email = $_POST["Email"];
    $Password = $_POST["Password"];

    //Creation du requete
    $sql = "SELECT * FROM vendeur WHERE Email='$Email' and Password='$Password'";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result)>0) {
    
        // echo "<a href=pagevendeur.html>acceder à votre page</a/>";
        // echo "<br>"; 
        header("Location: pagevendeur.html");
        exit();
    }
    else{
        echo "<h2>Le nom de compte ou le mot de passe est incorrecte</h2>";
    }
?>



