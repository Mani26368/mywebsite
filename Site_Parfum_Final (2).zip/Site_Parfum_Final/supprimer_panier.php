<?php
session_start();

if (!isset($_SESSION['utilisateur'])) {
    die("Accès non autorisé.");
}

// Vérification que l'ID du produit est envoyé
if (isset($_POST['Id_Parfum'])) {
    $idProduit = intval($_POST['Id_Parfum']);

    // Connexion à la base de données
    $conn = new mysqli("localhost", "root", "", "gestion_projet");
    if ($conn->connect_error) {
        die("Erreur de connexion : " . $conn->connect_error);
    }

    $emailUtilisateur = $_SESSION['utilisateur'];

    // Récupérer l'ID de l'utilisateur à partir de son email
    $sqlUtilisateur = "SELECT Id_utilisateur FROM utilisateur WHERE Email = ?";
    $stmtUtilisateur = $conn->prepare($sqlUtilisateur);
    if (!$stmtUtilisateur) {
        die("Erreur de préparation de la requête utilisateur : " . $conn->error);
    }
    $stmtUtilisateur->bind_param("s", $emailUtilisateur);
    $stmtUtilisateur->execute();
    $resultUtilisateur = $stmtUtilisateur->get_result();

    if ($rowUtilisateur = $resultUtilisateur->fetch_assoc()) {
        $idUtilisateur = $rowUtilisateur['Id_utilisateur'];
    } else {
        echo "Utilisateur non trouvé.";
        exit;
    }

    // Requête pour supprimer le produit du panier
    $sql = "DELETE FROM panier WHERE Id_Parfum = ? AND Id_utilisateur = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Erreur de préparation de la requête de suppression : " . $conn->error);  // Affiche l'erreur si la préparation échoue
    }
    $stmt->bind_param("ii", $idProduit, $idUtilisateur);

    if ($stmt->execute()) {
        // Produit supprimé avec succès
        header("Location: panier.php"); // Redirige vers la page du panier
    } else {
        echo "Erreur : Impossible de supprimer le produit.";
    }

    $stmt->close();
    $stmtUtilisateur->close();
    $conn->close();
} else {
    echo "Erreur : Aucun produit spécifié.";
}
?>
