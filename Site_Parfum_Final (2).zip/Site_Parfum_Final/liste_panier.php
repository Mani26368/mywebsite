<?php
// Configuration de la session
session_start();

// Connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";
$motdepasse = "";
$base = "gestion_projet";

$conn = mysqli_connect($serveur, $utilisateur, $motdepasse, $base);

if (!$conn) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

// Vérification si l'utilisateur est connecté
if (!isset($_SESSION['email'])) {
    echo "<p>Vous devez être connecté pour ajouter un produit au panier.</p>";
    echo "<p><a href='connexion.html'>Connectez-vous ici</a></p>";
    exit;
}

// Identifiant de l'utilisateur connecté
$emailUtilisateur = $_SESSION['email'];

// Récupérer l'ID de l'utilisateur à partir de son email
$sqlUtilisateur = "SELECT Id_utilisateur FROM utilisateur WHERE Email = ?";
$stmtUtilisateur = mysqli_prepare($conn, $sqlUtilisateur);
mysqli_stmt_bind_param($stmtUtilisateur, "s", $emailUtilisateur);
mysqli_stmt_execute($stmtUtilisateur);
$resultUtilisateur = mysqli_stmt_get_result($stmtUtilisateur);

// Vérification que l'utilisateur existe et récupération de son Id_utilisateur
if ($rowUtilisateur = mysqli_fetch_assoc($resultUtilisateur)) {
    $idUtilisateur = $rowUtilisateur['Id_utilisateur'];
} else {
    echo "<p>Utilisateur non trouvé.</p>";
    exit;
}

// ID du produit et quantité à ajouter
$idProduit = $_GET['id']; // ID du produit à ajouter
$quantite = isset($_GET['quantite']) ? intval($_GET['quantite']) : 1; // Quantité par défaut

// Vérification si le produit existe déjà dans le panier
$sqlCheck = "SELECT Quantite FROM panier WHERE Id_Parfum = ? AND Id_utilisateur = ?";
$stmtCheck = mysqli_prepare($conn, $sqlCheck);
mysqli_stmt_bind_param($stmtCheck, "ii", $idProduit, $idUtilisateur);
mysqli_stmt_execute($stmtCheck);
$resultCheck = mysqli_stmt_get_result($stmtCheck);

// Si le produit est déjà dans le panier, on met à jour la quantité
if ($rowCheck = mysqli_fetch_assoc($resultCheck)) {
    $nouvelleQuantite = $rowCheck['Quantite'] + $quantite; // Ajouter la nouvelle quantité
    $sqlUpdate = "UPDATE panier SET Quantite = ? WHERE Id_Parfum = ? AND Id_utilisateur = ?";
    $stmtUpdate = mysqli_prepare($conn, $sqlUpdate);
    mysqli_stmt_bind_param($stmtUpdate, "iii", $nouvelleQuantite, $idProduit, $idUtilisateur);
    $success = mysqli_stmt_execute($stmtUpdate);
    mysqli_stmt_close($stmtUpdate);

    if ($success) {
        echo "<p>La quantité du produit a été mise à jour avec succès.</p>";
    } else {
        echo "<p>Erreur lors de la mise à jour de la quantité.</p>";
    }
} else {
    // Sinon, ajouter un nouveau produit au panier
    $sqlInsertPanier = "INSERT INTO panier (Id_Parfum, Id_utilisateur, Quantite, commande_validee) VALUES (?, ?, ?, 0)";
    $stmtInsert = mysqli_prepare($conn, $sqlInsertPanier);
    mysqli_stmt_bind_param($stmtInsert, "iii", $idProduit, $idUtilisateur, $quantite);
    $success = mysqli_stmt_execute($stmtInsert);
    mysqli_stmt_close($stmtInsert);

    if ($success) {
        echo "<p>Le produit a été ajouté au panier.</p>";
    } else {
        echo "<p>Erreur lors de l'ajout du produit au panier.</p>";
    }
}

// Fermeture de la connexion
mysqli_stmt_close($stmtCheck);
mysqli_stmt_close($stmtUtilisateur);
mysqli_close($conn);

// Liens pour continuer l'achat ou voir le panier
echo "<p><a href='panier.php'>Voir le panier</a></p>";
echo "<p><a href='tous.php'>Continuer vos achats</a></p>";
?>
