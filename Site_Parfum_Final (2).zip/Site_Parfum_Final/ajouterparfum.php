<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "root", "", "gestion_projet");

if ($conn->connect_error) {
    die("Erreur de connexion à la base de données : " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $Nom_Parfum = $_POST['Nom_Parfum'];
    $Description = $_POST['Description'];
    $Prix_Parfum = $_POST['Prix_Parfum'];
    $Id_catalogue = $_POST['Id_catalogue'];
    $Id_marque = $_POST['Id_marque'];

    // Gérer l'image téléchargée
    $target_dir = "images/";  // Dossier où l'image sera enregistrée
    $image_name = basename($_FILES["Image"]["name"]);
    $imageFileType = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));
    
    // Créer un nom unique pour l'image en utilisant un timestamp
    $target_file = $target_dir . time() . "_" . uniqid() . "." . $imageFileType;

    // Vérifier si le fichier est une image réelle
    if (getimagesize($_FILES["Image"]["tmp_name"]) === false) {
        die("Ce fichier n'est pas une image.");
    }

    // Vérifier la taille de l'image (limite de 5 Mo par exemple)
    if ($_FILES["Image"]["size"] > 5000000) {
        die("L'image est trop grande.");
    }

    // Déplacer le fichier téléchargé dans le dossier cible
    if (!move_uploaded_file($_FILES["Image"]["tmp_name"], $target_file)) {
        die("Désolé, il y a eu une erreur lors de l'upload de l'image.");
    }

    // Préparer la requête SQL pour insérer les données dans la table parfum
    $sql = "INSERT INTO parfum (image, Nom_Parfum, Description, Prix_Parfum, Id_catalogue, Id_marque) 
            VALUES ('$target_file', '$Nom_Parfum', '$Description', '$Prix_Parfum', '$Id_catalogue', '$Id_marque')";

    if ($conn->query($sql) === TRUE) {
        echo "<p style='color: green; font-weight: bold;'>Le parfum a été ajouté avec succès !</p>";
    } else {
        echo "<p style='color: red;'>Erreur: " . $sql . "<br>" . $conn->error . "</p>";
    }

    // Fermer la connexion à la base de données
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Parfum</title>
    <style>
        /* Global Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #74b9ff, #00cec9);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
        }

        /* Conteneur principal du formulaire */
        .form-container {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 90%;
            max-width: 600px;
            transition: transform 0.3s ease-in-out;
        }

        .form-container:hover {
            transform: scale(1.02);
        }

        h1 {
            text-align: center;
            color: #2d3436;
            font-size: 28px;
            margin-bottom: 20px;
        }

        /* Styles du formulaire */
        label {
            font-size: 16px;
            color: #2d3436;
            font-weight: bold;
            margin-bottom: 8px;
            display: block;
        }

        input[type="text"],
        input[type="number"],
        textarea,
        select,
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            font-size: 14px;
            border: 2px solid #ddd;
            border-radius: 8px;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="number"]:focus,
        textarea:focus,
        select:focus,
        input[type="file"]:focus {
            border-color: #0984e3;
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        input[type="submit"] {
            background-color: #0984e3;
            color: white;
            font-size: 18px;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #6c5ce7;
            transform: translateY(-2px);
        }

        input[type="submit"]:active {
            transform: translateY(0);
            background-color: #4e43d2;
        }

        /* Bouton Admin */
        .btn-admin {
            background-color: #6c5ce7;
            color: white;
            font-size: 18px;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-left: 10px;
            transition: background-color 0.3s ease, transform 0.2s ease;
            width: 100%;
        }

        .btn-admin:hover {
            background-color: #4e43d2;
            transform: translateY(-2px);
        }

        .btn-admin:active {
            transform: translateY(0);
            background-color: #3e39b1;
        }

        /* Disposition des boutons */
        .button-container {
            display: flex;
            justify-content: space-between;
            gap: 10px;
        }

        /* Responsivité */
        @media (max-width: 768px) {
            .form-container {
                padding: 20px;
                width: 95%;
            }

            h1 {
                font-size: 24px;
            }

            .button-container {
                flex-direction: column;
                gap: 10px;
            }

            .btn-admin {
                width: 100%;
            }
        }

    </style>
</head>
<body>

<div class="form-container">
    <h1>Ajouter un Parfum</h1>

    <form method="POST" enctype="multipart/form-data">
        <label for="Nom_Parfum">Nom du parfum :</label>
        <input type="text" id="Nom_Parfum" name="Nom_Parfum" required><br><br>

        <label for="Description">Description :</label>
        <input type="text" id="Description" name="Description" required><br><br>

        <label for="Prix_Parfum">Prix :</label>
        <input type="number" id="Prix_Parfum" name="Prix_Parfum" step="0.01" required><br><br>

        <label for="Catalogue">Catalogue :</label>
        <select name="Id_catalogue" id="Catalogue" required>
            <option value="1">Homme</option>
            <option value="2">Femme</option>
            <option value="3">Mixte</option>
        </select><br><br>

        <label for="Marque">Marque :</label>
        <select name="Id_marque" id="Marque" required>
            <?php
            // Connexion à la base de données et récupérer les marques
            $conn = new mysqli("localhost", "root", "", "gestion_projet");

            if ($conn->connect_error) {
                die("Erreur de connexion à la base de données : " . $conn->connect_error);
            }

            $sql = "SELECT * FROM marque";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['Id_Marque'] . "'>" . $row['Nom_Marque'] . "</option>";
                }
            } else {
                echo "<option value=''>Aucune marque disponible</option>";
            }

            $conn->close();
            ?>
        </select><br><br>

        <label for="Image">Image du Parfum :</label>
        <input type="file" id="Image" name="Image" accept="image/*" required><br><br>

        <div class="button-container">
            <input type="submit" value="Ajouter le parfum">
            <!-- Bouton vers la page administrateur -->
            <a href="Administrateur.php">
                            <input type="button" value="Administrateur" style="background-color: #e74c3c; color: white; border: none; padding: 15px 25px; border-radius: 8px; cursor: pointer; transition: background-color 0.3s ease; font-size: 18px;">
                        </a>
        </div>
    </form>
</div>

</body>
</html>
