<?php
// Initialisation de la session
session_start();

// Définir la durée maximale d'inactivité (en secondes)
$inactivityDuration = 1800; // 30 minutes

// Vérifier si l'utilisateur est inactif
if (isset($_SESSION['last_activity'])) {
    $timeInactive = time() - $_SESSION['last_activity'];
    if ($timeInactive > $inactivityDuration) {
        // Si l'utilisateur est inactif depuis trop longtemps, détruire la session
        session_unset();
        session_destroy();
        header("Location: index.html"); // Rediriger vers la page de connexion
        exit();
    }
}

// Mettre à jour l'heure de la dernière activité
$_SESSION['last_activity'] = time();
?>
