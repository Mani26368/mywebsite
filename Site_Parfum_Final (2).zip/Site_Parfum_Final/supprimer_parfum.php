<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "root", "", "gestion_projet");

if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Variable pour le message
$message = "";

// Récupérer la liste des parfums pour la sélection
$sql = "SELECT Id_Parfum, Nom_Parfum, image FROM parfum";
$result = $conn->query($sql);

// Vérifier si le formulaire a été soumis et si un parfum a été sélectionné
if (isset($_POST['supprimer']) && isset($_POST['parfum']) && !empty($_POST['parfum'])) {
    $idParfum = $_POST['parfum'];

    // Préparer et exécuter la requête de suppression
    $sql = "DELETE FROM parfum WHERE Id_Parfum = ?";
    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        $message = "Erreur dans la préparation de la requête : " . $conn->error;
    } else {
        // Lier le paramètre
        $stmt->bind_param("i", $idParfum);

        // Exécuter la suppression
        if ($stmt->execute()) {
            // Si la suppression a réussi
            $message = "Le parfum a été supprimé avec succès.";
        } else {
            // Si la suppression échoue
            $message = "Erreur lors de la suppression du parfum.";
        }
    }
}

// Fermer la connexion à la base de données
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer un Parfum</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> <!-- Ajout des icônes Material Icons -->
    <style>
        /* Global Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
        }

        /* Conteneur principal du formulaire */
        .form-container {
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 100%;
            max-width: 450px;
            transition: transform 0.3s ease-in-out;
        }

        .form-container:hover {
            transform: scale(1.05);
        }

        h2 {
            text-align: center;
            color: #2d3436;
            font-size: 32px;
            margin-bottom: 30px;
        }

        /* Styles du formulaire */
        .input-container {
            position: relative;
            margin-bottom: 20px;
        }

        .input-container select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            font-size: 16px;
            border: 2px solid #ddd;
            border-radius: 8px;
            padding-left: 40px; /* Pour laisser de la place à l'icône */
            transition: border-color 0.3s ease;
        }

        .input-container select:focus {
            border-color: #0984e3;
        }

        .input-container .material-icons {
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            color: #aaa;
        }

        button {
            padding: 12px 25px;
            font-size: 18px;
            background-color: #3498db;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.2s ease;
            width: 100%;
            margin-bottom: 10px;
        }

        button:hover {
            background-color: #2980b9;
            transform: translateY(-3px);
        }

        button:active {
            transform: translateY(0);
            background-color: #217dbb;
        }

        .return-button {
            background-color: #e74c3c;
            margin-top: 10px;
        }

        .return-button:hover {
            background-color: #c0392b;
        }

        /* Messages de confirmation */
        .message {
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
            border-radius: 8px;
            padding: 15px;
            margin-top: 40px;
        }

        .message.success {
            background-color: #28a745;
            color: white;
        }

        .message.error {
            background-color: #dc3545;
            color: white;
        }

        /* Section pour afficher le nom et l'image du parfum */
        .parfum-info {
            margin-top: 20px;
            text-align: center;
        }

        .parfum-info img {
            max-width: 150px;
            max-height: 150px;
            margin-top: 10px;
            border-radius: 8px;
        }

        /* Responsivité */
        @media (max-width: 768px) {
            .form-container {
                padding: 20px;
                width: 90%;
            }

            h2 {
                font-size: 28px;
            }

            button {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Supprimer un Parfum</h2>
    
    <!-- Affichage du message -->
    <?php if (!empty($message)) : ?>
        <div class="message <?php echo strpos($message, 'succès') !== false ? 'success' : 'error'; ?>"><?php echo $message; ?></div>
    <?php endif; ?>

    <?php if ($result->num_rows > 0) : ?>
        <!-- Formulaire de suppression du parfum -->
        <form action="supprimer_parfum.php" method="POST">
            <div class="input-container">
                <span class="material-icons">delete</span>
                <select name="parfum" id="parfum" required onchange="updateParfumInfo()">
                    <option value="">Sélectionner un parfum</option>
                    <?php while ($row = $result->fetch_assoc()) : ?>
                        <option value="<?php echo $row['Id_Parfum']; ?>" data-name="<?php echo $row['Nom_Parfum']; ?>" data-image="<?php echo $row['image']; ?>"><?php echo $row['Nom_Parfum']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <!-- Affichage du nom et de l'image du parfum sélectionné -->
            <div class="parfum-info" id="parfum-info">
                <p id="parfum-name"></p>
                <img id="parfum-image" src="" alt="Image du parfum">
            </div>

            <button type="submit" name="supprimer" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce parfum ?');">Supprimer</button>
        </form>
    <?php else : ?>
        <p>Aucun parfum disponible pour suppression.</p>
    <?php endif; ?>

    <!-- Bouton Retour à l'Administrateur -->
    <a href="Administrateur.php">
                            <input type="button" value="Administrateur" style="background-color: #e74c3c; color: white; border: none; padding: 15px 25px; border-radius: 8px; cursor: pointer; transition: background-color 0.3s ease; font-size: 18px;">
                        </a>
</div>

<script>
    // Fonction JavaScript pour mettre à jour l'affichage du nom et de l'image du parfum sélectionné
    function updateParfumInfo() {
        const select = document.getElementById('parfum');
        const selectedOption = select.options[select.selectedIndex];
        
        const name = selectedOption.getAttribute('data-name');
        const image = selectedOption.getAttribute('data-image');
        
        // Mettre à jour l'affichage du nom et de l'image
        document.getElementById('parfum-name').textContent = name;
        document.getElementById('parfum-image').src = image;
    }
</script>

</body>
</html>
