<?php
// Connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";
$motdepasse = "";
$base = "gestion_projet";

$conn = mysqli_connect($serveur, $utilisateur, $motdepasse, $base);

if (!$conn) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

// Vérifier si un jeton est fourni dans l'URL
if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Vérifier si le jeton est valide et non expiré
    $sql = "SELECT * FROM utilisateur WHERE reset_token = ? AND reset_expires > ?";
    $stmt = mysqli_prepare($conn, $sql);
    $now = date("Y-m-d H:i:s");
    mysqli_stmt_bind_param($stmt, "ss", $token, $now);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $email = $row['Email']; // Récupérer l'email associé au jeton

        // Si le formulaire de réinitialisation est soumis
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $newPassword = $_POST['new_password'];
            $confirmPassword = $_POST['confirm_password'];

            // Vérifier si les mots de passe correspondent
            if ($newPassword === $confirmPassword) {
                // Hacher le nouveau mot de passe
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

                // Mettre à jour le mot de passe dans la base de données
                $sqlUpdate = "UPDATE utilisateur SET password = ?, reset_token = NULL, reset_expires = NULL WHERE Email = ?";
                $stmtUpdate = mysqli_prepare($conn, $sqlUpdate);
                mysqli_stmt_bind_param($stmtUpdate, "ss", $hashedPassword, $email);
                mysqli_stmt_execute($stmtUpdate);

                echo "<h2>Votre mot de passe a été réinitialisé avec succès. Vous pouvez maintenant <a href='connexion.html'>vous connecter</a>.</h2>";
                exit();
            } else {
                echo "<h3>Les mots de passe ne correspondent pas. Veuillez réessayer.</h3>";
            }
        }
    } else {
        echo "<h2>Le lien de réinitialisation est invalide ou a expiré.</h2>";
        exit();
    }
} else {
    echo "<h2>Aucun jeton de réinitialisation fourni.</h2>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialiser le Mot de Passe</title>
</head>
<body>
    <center>
        <div class="container">
            <h2>Réinitialiser votre mot de passe</h2>
            <form method="POST" action="">
                <input type="password" name="new_password" placeholder="Nouveau mot de passe" required />
                <input type="password" name="confirm_password" placeholder="Confirmer le mot de passe" required />
                <button type="submit">Réinitialiser</button>
            </form>
        </div>
    </center>
</body>
</html>
