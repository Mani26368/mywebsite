<?php
// Configuration de la session
session_start();

// Vérification si l'utilisateur est connecté
if (!isset($_SESSION['utilisateur'])) {
    echo "<p>Vous devez être connecté pour valider votre panier.</p>";
    exit;
}

// Connexion à la base de données
$serveur = "localhost";
$utilisateur = "root";
$motdepasse = "";
$base = "gestion_projet";

$conn = mysqli_connect($serveur, $utilisateur, $motdepasse, $base);

if (!$conn) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

// Identifiant de l'utilisateur connecté (email de l'utilisateur)
$emailUtilisateur = $_SESSION['utilisateur'];

// Récupérer l'ID de l'utilisateur à partir de son email
$sqlUtilisateur = "SELECT Id_utilisateur FROM utilisateur WHERE Email = ?";
$stmtUtilisateur = mysqli_prepare($conn, $sqlUtilisateur);
if (!$stmtUtilisateur) {
    die("Erreur de préparation de la requête utilisateur : " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmtUtilisateur, "s", $emailUtilisateur);
mysqli_stmt_execute($stmtUtilisateur);
$resultUtilisateur = mysqli_stmt_get_result($stmtUtilisateur);

// Vérification que l'utilisateur existe et récupération de son Id_utilisateur
if ($rowUtilisateur = mysqli_fetch_assoc($resultUtilisateur)) {
    $idUtilisateur = $rowUtilisateur['Id_utilisateur'];
} else {
    echo "<p>Utilisateur non trouvé.</p>";
    exit;
}

// Requête pour récupérer les produits dans le panier de cet utilisateur
$sqlPanier = "
    SELECT pa.Id_Parfum, pa.Quantite, p.Prix_Parfum
    FROM panier pa
    JOIN parfum p ON pa.Id_Parfum = p.Id_Parfum
    WHERE pa.Id_utilisateur = ?
";
$stmt = mysqli_prepare($conn, $sqlPanier);
if (!$stmt) {
    die("Erreur de préparation de la requête panier : " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $idUtilisateur);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Préparation des données pour la commande
$total = 0;
$parfums = [];

while ($row = mysqli_fetch_assoc($result)) {
    $total += $row['Prix_Parfum'] * $row['Quantite']; // Calcul du total
    $parfums[] = [
        'Id_Parfum' => $row['Id_Parfum'],
        'Quantite' => $row['Quantite']
    ];
}
mysqli_stmt_close($stmt);

// Validation du montant total
if ($total > 99999999.99 || $total < 0) {
    die("Erreur : le montant total calculé est en dehors des limites autorisées.");
}

// Calcul de la Date_livraison_estimee (ajouter 7 jours à la date actuelle)
$dateLivraisonEstimee = date('Y-m-d', strtotime('+7 days'));

// Insérer les commandes pour chaque produit
foreach ($parfums as $parfum) {
    $sqlCommande = "
        INSERT INTO commande (Id_utilisateur, Date_commande, Montant_total, valide, Date_livraison_estimee, Id_parfum, Quantite) 
        VALUES (?, NOW(), ?, 1, ?, ?, ?)";
    $stmtCommande = mysqli_prepare($conn, $sqlCommande);
    if (!$stmtCommande) {
        die("Erreur de préparation de la requête commande : " . mysqli_error($conn));
    }

    $montantTotalProduit = $parfum['Quantite'] * $total; // Montant total pour ce produit
    mysqli_stmt_bind_param($stmtCommande, "idsii", $idUtilisateur, $montantTotalProduit, $dateLivraisonEstimee, $parfum['Id_Parfum'], $parfum['Quantite']);
    $executionCommande = mysqli_stmt_execute($stmtCommande);
    if (!$executionCommande) {
        die("Erreur d'exécution de la requête commande : " . mysqli_stmt_error($stmtCommande));
    }

    mysqli_stmt_close($stmtCommande);

    // Une fois la commande insérée, supprimer l'article du panier
    $sqlSupprimerPanier = "DELETE FROM panier WHERE Id_utilisateur = ? AND Id_Parfum = ?";
    $stmtSupprimerPanier = mysqli_prepare($conn, $sqlSupprimerPanier);
    if (!$stmtSupprimerPanier) {
        die("Erreur de préparation de la requête suppression panier : " . mysqli_error($conn));
    }
    
    mysqli_stmt_bind_param($stmtSupprimerPanier, "ii", $idUtilisateur, $parfum['Id_Parfum']);
    $executionSuppression = mysqli_stmt_execute($stmtSupprimerPanier);
    if (!$executionSuppression) {
        die("Erreur d'exécution de la suppression du panier : " . mysqli_stmt_error($stmtSupprimerPanier));
    }

    mysqli_stmt_close($stmtSupprimerPanier);
}

echo "<div>Votre commande a bien été enregistrée avec plusieurs parfums. <a href='tous.php'>Retour aux produits</a></div>";

// Fermer la connexion à la base de données
mysqli_close($conn);
?>

<!-- Bouton "Payer maintenant" -->
<a href="paypal.php?total=<?php echo $total; ?>" class="button-payer">Payer maintenant</a>
